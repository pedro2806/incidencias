<!DOCTYPE html>
<html lang = "en">

<head>

    <meta charset = "utf-8">
    <meta http-equiv = "X-UA-Compatible" content = "IE = edge">
    <meta name = "viewport" content = "width = device-width, initial-scale = 1, shrink-to-fit = no">
    <meta name = "description" content = "">
    <meta name = "author" content = "">

    <title>RR HH</title>

    <!-- Custom fonts for this template-->
    <link href = "vendor/fontawesome-free/css/all.min.css" rel = "stylesheet" type = "text/css">
    <link href = "https://fonts.googleapis.com/css?family = Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel = "stylesheet">

    <!-- Custom styles for this template-->
    <link href = "css/sb-admin-2.min.css" rel = "stylesheet">
    <link href="https://cdn.datatables.net/1.13.2/css/jquery.dataTables.min.css" rel="stylesheet" crossorigin="anonymous">
</head>

<body id = "page-top">

    <!-- Page Wrapper -->
    <div id = "wrapper">
        <?php
            session_start();
            //if(isset($_SESSION['nombredelusuario'])){}
            
            include 'menu.php';
        ?>

        

        <!-- Content Wrapper -->
        <div id = "content-wrapper" class = "d-flex flex-column">

            <!-- Main Content -->
            <div id = "content">
            
                <?php
                    //session_start();
                    //if(isset($_SESSION['nombredelusuario'])){}
                    
                    include 'encabezado.php';
                ?>
                

                <!-- Begin Page Content -->
                <div class = "container-fluid">

                    <!-- Page Heading -->
                    <div class = "d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class = "h3 mb-0 text-gray-800">Personal MESS</h1>                        
                    </div>

                    <!-- Content Row -->

                    <div class = "row">

                        <!-- Area Chart -->
                        <div class = "col-xl-12">
                            <div class = "card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class = "card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class = "m-0 font-weight-bold text-info">Personal MESS</h6>                                    
                                </div>
                                <!-- Card Body -->
                                    <div class = "card-body">
                                        <div class = "row">                                            
                                            <div class = "col-xl-12">
                                            <table  class="table-responsive table-sm table-striped display compact" id ="Tusuarios" name="Tusuarios">
                                                <thead class="table-info">
                                                    <tr>                                                    
                                                        <th scope="col">No</th>
                                                        <th scope="col">Nombre</th>
                                                        <!--<th scope="col">Correo</th>-->
                                                        <th scope="col">Puesto</th>
                                                        <th scope="col">Region</th>
                                                        <th scope="col">Depto</th>
                                                        <th scope="col">Fecha de ingreso</th>
                                                        <th scope="col">Antigüedad</th>
                                                        <th scope="col">Días</th>
                                                        <th scope="col">Estatus</th>
                                                        <th scope="col">Acciones</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php                                                    
                                                        include 'conn.php';
                                                        $Qusuarios = "SELECT U.id, U.noEmpleado, U.nombre, U.correo, P.puesto, R.region, D.departamento, U.fechaIngreso, U.estatus, TIMESTAMPDIFF(YEAR,fechaIngreso,CURDATE()) AS antiguedad
                                                        FROM usuarios U
                                                        INNER JOIN puesto P ON U.puesto = P.id
                                                        INNER JOIN region R ON U.region = R.id
                                                        INNER JOIN departamento D ON U.departamento = D.id";                                                        
                                                        $res2= mysqli_query( $conn, $Qusuarios ) or die (mysqli_error($conn));
                                                        
                                                        While ($row2 = mysqli_fetch_array($res2)){
                                                            $id = $row2["id"];
                                                            $noEmpleado = $row2["noEmpleado"];                            
                                                            $nombre = $row2["nombre"];
                                                            $correo = $row2["correo"];
                                                            $puesto = $row2["puesto"];
                                                            $region = $row2["region"];
                                                            $fechaIngreso = $row2["fechaIngreso"];
                                                            $departamento = $row2["departamento"];
                                                            $estatus = $row2["estatus"];
                                                            $antiguedad = $row2["antiguedad"];
                                                            
                                                            $Qdias = "SELECT * FROM diasvacaciones WHERE anio = $antiguedad";
                                                            $resdias= mysqli_query( $conn, $Qdias ) or die (mysqli_error($conn));
                                                            
                                                            While ($row3 = mysqli_fetch_array($resdias)){
                                                                $dias = $row3["dias"];
                                                            }
                                                            //<td>'.$correo.'</td>
                                                            echo '<tr>                                                                    
                                                                    <td>'.$noEmpleado.'</td>
                                                                    <td>'.$nombre.'</td>                                                                    
                                                                    <td>'.$puesto.'</td>
                                                                    <td>'.$region.'</td>
                                                                    <td>'.$departamento.'</td>
                                                                    <td>'.$fechaIngreso.'</td>
                                                                    <td>'.$antiguedad.'</td>
                                                                    <td>'.$dias.'</td>
                                                                    <td>'.$estatus.'</td>
                                                                    <td>
                                                                        <a href="#" class="btn btn-success btn-circle btn-sm">
                                                                            <i class="fas fa-check"></i>
                                                                        </a>
                                                                        <a href="#" class="btn btn-danger btn-circle btn-sm">
                                                                            <i class="fas fa-trash"></i>
                                                                        </a>
                                                                    </td>
                                                                </tr>';
                                                        
                                                        }

                                                    ?>                                                    
                                                </tbody>
                                            </table>
                                            </div>                                            
                                        </div>                                        
                                </div>
                            </div>
                        </div>
                    </div>                    

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class = "sticky-footer bg-white">
                <div class = "container my-auto">
                    <div class = "copyright text-center my-auto">
                        <span>Copyright &copy; MESS 2023</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class = "scroll-to-top rounded" href = "#page-top">
        <i class = "fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class = "modal fade" id = "logoutModal" tabindex = "-1" role = "dialog" aria-labelledby = "exampleModalLabel"
        aria-hidden = "true">
        <div class = "modal-dialog" role = "document">
            <div class = "modal-content">
                <div class = "modal-header">
                    <h5 class = "modal-title" id = "exampleModalLabel">Cerrar sesión</h5>
                    <button class = "close" type = "button" data-dismiss = "modal" aria-label = "Close">
                        <span aria-hidden = "true">×</span>
                    </button>
                </div>
                <div class = "modal-body">¿Estas seguro?</div>
                <div class = "modal-footer">
                    <button class = "btn btn-info" type = "button" data-dismiss = "modal">Cancelar</button>
                    <a class = "btn btn-danger" href = "logout">Salir</a>
                </div>
            </div>
        </div>
    </div>
    </body>
    <!-- Bootstrap core JavaScript-->
    <script src = "vendor/jquery/jquery.min.js"></script>
    <script src = "vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src = "vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src = "js/sb-admin-2.min.js"></script>
    <script type="text/javascript">
    
        $(document).ready(function () {
            $('#Tusuarios').DataTable({
                language: {
                url: 'https://cdn.datatables.net/plug-ins/1.10.24/i18n/Spanish_Mexico.json'
                },
            });
        });
    </script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.8/js/jquery.dataTables.min.js" defer="defer"></script>
 
</html>