<?php 
include 'conn.php';
?>
<!-- Content Row -->
<div class = "row">

    <!-- Earnings (Monthly) Card Example -->
    <div class = "col-xl-3 col-md-6 mb-5">
        <div class = "card border-left-primary shadow h-60 py-0">
            <div class = "card-body">
                <div class = "row no-gutters align-items-center">
                    <div class = "col mr-2">
                        <div class = "text-md font-weight-bold text-primary text-uppercase mb-1">
                            <?php echo $_SESSION['nombredelusuario']; ?>                        
                        </div>                                            
                        <div class = "h5 mb-0 font-weight-bold text-gray-800">
                            No. Empleado: <?php echo $_SESSION['noEmpleado']; ?>
                        </div>
                    </div>                                        
                </div>
            </div>
        </div>
    </div>

    <!-- Earnings (Monthly) Card Example -->
    <div class = "col-xl-2 col-md-6 mb-5">
        <div class = "card border-left-info shadow h-60 py-0">
            <div class = "card-body">
                <div class = "row no-gutters align-items-center">
                    <div class = "col mr-2">
                        <div class = "text-md font-weight-bold text-info text-uppercase mb-1">
                            Antigüedad
                        </div>
                        <div class = "h5 mb-0 font-weight-bold text-gray-800">
                            <?php echo $_SESSION['antiguedad']; ?>  años
                        </div>
                    </div>                    
                </div>
            </div>
        </div>
    </div>

    <!-- Earnings (Monthly) Card Example -->
    <div class = "col-xl-2 col-md-6 mb-5">
        <div class = "card border-left-secondary shadow h-60 py-0">
            <div class = "card-body">
                <div class = "row no-gutters align-items-center">
                    <div class = "col mr-2">
                        <div class = "text-md font-weight-bold text-secondary text-uppercase mb-1">
                            Vac. por ley
                        </div>
                        <div class = "h5 mb-0 font-weight-bold text-gray-800">
                            <?php
                               $antiguedad = $_SESSION['antiguedad'];
                                
                                $Qdias = "SELECT * FROM diasvacaciones WHERE anio = $antiguedad";
                                $resdias= mysqli_query( $conn, $Qdias ) or die (mysqli_error($conn));
                                
                                While ($row3 = mysqli_fetch_array($resdias)){
                                    $dias = $row3["dias"];
                                }
                                echo $dias;
                            ?> días
                        </div>
                    </div>                    
                </div>
            </div>
        </div>
    </div>

    <!-- Earnings (Monthly) Card Example -->
    <div class = "col-xl-2 col-md-6 mb-5">
        <div class = "card border-left-warning shadow h-60 py-0">
            <div class = "card-body">
                <div class = "row no-gutters align-items-center">
                    <div class = "col mr-2">
                        <div class = "text-md font-weight-bold text-warning text-uppercase mb-1">
                            Días solicitados
                        </div>
                        <div class = "h5 mb-0 font-weight-bold text-gray-800">
                            5 días
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

        <!-- Earnings (Monthly) Card Example -->
        <div class = "col-xl-2 col-md-6 mb-5">
        <div class = "card border-left-success shadow h-60 py-0">
            <div class = "card-body">
                <div class = "row no-gutters align-items-center">
                    <div class = "col mr-2">
                        <div class = "text-md font-weight-bold text-success text-uppercase mb-1">
                            Días Disponibles
                        </div>
                        <div class = "h5 mb-0 font-weight-bold text-gray-800">
                        <?php echo $_SESSION['diasD']; ?>  días  
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>    

</div>