<?php 

//$conn = mysqli_connect("localhost", "webmess_incidencias", "Pipmytrade123", "webmess_rrhh");
//incidencias2023
    //$conn  =  mysqli_connect("localhost", "predictor", "predictor2022") or die (mysql_error($conn));
    //mysqli_select_db($conn, "rrhh") or die (mysqli_error($conn));                        


    $conn = mysqli_connect("localhost", "predictor", "predictor2022", "rrhh");
    
    // Check connection
    if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
    }else{
    //echo "Connected successfully";
    }
?>