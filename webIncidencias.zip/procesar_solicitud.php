<?php

include 'conn.php';
session_start();
$opIncidencia = $_POST['opIncidencia'];
$fechaInicial = $_POST['fechaInicial'];
$fechaFinal = $_POST['fechaFinal'];
$noDias = $_POST['noDias'];
$notas = $_POST['notas'];
$hoy = date("Y-m-d");
$noEmpleado = $_SESSION['noEmpleado'];

$sql = "INSERT INTO solicitudes(empleado, tipo, feinicio, fefin, fesolicitud, dias, notasempleado, notajefe, estatus) 
                    VALUES ($noEmpleado, '$opIncidencia', '$fechaInicial', '$fechaFinal', '$hoy', $noDias, '$notas', '', 1)";

mysqli_query($conn, $sql);
//return $resultado;
    echo '<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>';
    echo '<script>swal("¡Tu solicitud fue procesada con éxito!", "", "success");</script>';
    header("location: solicitudesestatus");
?>